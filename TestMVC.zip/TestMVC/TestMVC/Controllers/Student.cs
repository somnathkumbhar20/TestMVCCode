﻿namespace TestMVC.Controllers
{
    public class Student
    {
        public string StudentId { get; set; }
        public string StudentName { get; set; }
        public int StudentAge { get; set; }
    }
}