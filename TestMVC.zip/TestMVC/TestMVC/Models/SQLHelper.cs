﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TestMVC.Controllers;

namespace TestMVC.Models
{
    public class SQLHelper
    {
        public static List<Student> StudentList = new List<Student>();
        public static void AddStudent(Student student)
        {
            StudentList.Add(student);
        }

        public static IEnumerable <Student> GetAllStudents()
        {
            return StudentList;
        }
    }
}